#ifndef degree_H
#define degree_H
using namespace std;



enum Degree
{
	SECURITY, NETWORKING, SOFTWARE
};




#endif;